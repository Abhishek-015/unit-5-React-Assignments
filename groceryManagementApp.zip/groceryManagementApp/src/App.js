import "./App.css"
import Grocery from "./components/grocery"


const App=()=>{
 
  return(
    <>
    <Grocery/>
    </>
  )
}



export default App